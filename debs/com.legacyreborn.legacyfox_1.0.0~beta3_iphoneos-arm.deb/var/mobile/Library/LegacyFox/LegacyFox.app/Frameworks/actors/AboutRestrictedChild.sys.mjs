/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

import { RemotePageChild } from "resource://gre/actors/RemotePageChild.sys.mjs";

export class AboutRestrictedChild extends RemotePageChild {
  actorCreated() {
    super.actorCreated();
    const exportableFunctions = ["RPMGetBoolPref"];
    this.exportFunctions(exportableFunctions);
  }
}
