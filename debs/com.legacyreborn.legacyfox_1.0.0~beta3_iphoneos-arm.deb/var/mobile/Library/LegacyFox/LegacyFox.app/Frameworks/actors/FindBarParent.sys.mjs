/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

// Map of browser elements to findbars.
let findbars = new WeakMap();

export class FindBarParent extends JSWindowActorParent {
  setFindbar(browser, findbar) {
    if (findbar) {
      findbars.set(browser, findbar);
    } else {
      findbars.delete(browser, findbar);
    }
  }

  receiveMessage(message) {
    let browser = this.manager.browsingContext.top.embedderElement;
    if (!browser) {
      return;
    }

    let respondToMessage = () => {
      let findBar = findbars.get(browser);
      if (!findBar) {
        return;
      }

      switch (message.name) {
        case "Findbar:Keypress": {
          let d = message.data || {};
          findBar._onBrowserKeypress({
            type: "keypress",
            bubbles: false,
            cancelable: !!d.cancelable,
            ctrlKey: !!d.ctrlKey,
            altKey: !!d.altKey,
            shiftKey: !!d.shiftKey,
            metaKey: !!d.metaKey,
            keyCode: (d.keyCode | 0) & 0xffff,
            charCode: (d.charCode | 0) & 0xffff,
          });
          break;
        }
        case "Findbar:Mouseup":
          findBar.onMouseUp();
          break;
      }
    };

    let findPromise = browser.documentGlobal.gFindBarPromise;
    if (findPromise) {
      findPromise.then(respondToMessage);
    } else {
      respondToMessage();
    }
  }
}
